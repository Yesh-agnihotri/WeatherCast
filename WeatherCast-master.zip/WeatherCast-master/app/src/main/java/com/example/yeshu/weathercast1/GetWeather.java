package com.example.yeshu.weathercast1;

/**
 * Created by yeshu on 13-09-2016.
 */
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

public class GetWeather
{
    static final String weather_url ="http://api.openweathermap.org/data/2.5/weather?q=%s&units=metric";
    static final String api_id = "025134d1ae0ad7f1d8fda20c8c965a46";

    public interface Response //to pass the values from asynctask to processfinish
    {

        void processFinish(String output1, String output2, String output3, String output4, String output5,String output6,String output7);
    }



    public static String setWeatherIcon(int actualId, long sunrise, long sunset)
    {
        int id = actualId / 100;
        String icon = "";
        if(actualId == 800){
            long currentTime = new Date().getTime();
            if(currentTime>=sunrise && currentTime<sunset) {
                icon = "&#xf00d;";
            } else {
                icon = "&#xf02e;";
            }
        } else {
            switch(id) {
                case 2 : icon = "&#xf01e;";
                    break;
                case 3 : icon = "&#xf01c;";
                    break;
                case 7 : icon = "&#xf014;";
                    break;
                case 8 : icon = "&#xf013;";
                    break;
                case 6 : icon = "&#xf01b;";
                    break;
                case 5 : icon = "&#xf019;";
                    break;
            }
        }
        return icon;
    }

    public static class weatherTask extends AsyncTask<String, Void, JSONObject>
    {
        public Response delegate = null; //as a listener

        @Override
        protected JSONObject doInBackground(String... params) {

            JSONObject jsonWeather = null;
            try
            {
                jsonWeather = access_api(params[0]);
            } catch (Exception e) {
                Log.d("Error", "Cannot process JSON results", e);
            }
            return jsonWeather;
        }

        @Override
        protected void onPostExecute(JSONObject jsonWeather) {
            try {
                if(jsonWeather != null)

                {

                    JSONObject weatherArray = jsonWeather.getJSONArray("weather").getJSONObject(0);//as the jason is in array form
                    JSONObject main = jsonWeather.getJSONObject("main");
                    DateFormat df = DateFormat.getDateTimeInstance();

                    String cityname = jsonWeather.getString("name")+ ", " + jsonWeather.getJSONObject("sys").getString("country");
                    String condition = weatherArray.getString("description").toUpperCase(Locale.US);
                    String temperature = String.format("%.2f", main.getDouble("temp"))+ "°";//to covert to 2 decimal place
                    String humidity = main.getString("humidity") + "%";
                    String pressure = main.getString("pressure") + " hPa";
                    String lastUpdate = df.format(new Date(jsonWeather.getLong("dt")*1000));
                    String iconText = setWeatherIcon(weatherArray.getInt("id"),
                            jsonWeather.getJSONObject("sys").getLong("sunrise") * 1000,
                            jsonWeather.getJSONObject("sys").getLong("sunset") * 1000);
                    delegate.processFinish(cityname, condition, temperature, humidity, pressure,lastUpdate,iconText);

                }
            }
            catch (JSONException e)
            {
                return;
            }
        }
    }
    public static JSONObject access_api(String city){
        try
        {
            URL url = new URL(String.format(weather_url, city));
            HttpURLConnection conn = (HttpURLConnection)url.openConnection();

            conn.addRequestProperty("x-api-key", api_id);//add my api key to url

            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));//to get input from url
            StringBuffer json = new StringBuffer(1024);
            String readData="";
            while((readData=reader.readLine())!=null)
                json.append(readData).append("\n");
            reader.close();
            JSONObject data = new JSONObject(json.toString());
            if(data.getInt("cod") == 200)//an internal parameter for this weather jason
            {
                return data;
            }
            else
            {
                return null;
            }

        }
        catch(Exception e)
        {
            return null;
        }
    }
}

