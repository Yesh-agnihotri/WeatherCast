package com.example.yeshu.weathercast1;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.w3c.dom.Text;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback,GoogleMap.OnMapClickListener,GoogleMap.OnMarkerClickListener,GetWeatherMap.ResponseMap {

    private GoogleMap mMap;
    Marker marker;
    Text cityname;
    LatLng point;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R
                .layout.activity_maps);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.getUiSettings().setMapToolbarEnabled(false); //to disable navigation buttons
        mMap.setOnMapClickListener(this);
    }

    @Override
    public void onMapClick(LatLng latLng)
    {
        if(marker!=null)
        {
            marker.remove();
        }

        point = new LatLng(latLng.latitude, latLng.longitude);
        marker=mMap.addMarker(new MarkerOptions().position(point));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(point));
        mMap.setOnMarkerClickListener(this);
    }

    @Override
    public boolean onMarkerClick(Marker marker)
    {
        GetWeatherMap.MapWeatherTask obj = new GetWeatherMap.MapWeatherTask();
        obj.delegate=this;
        LatLng latlng=point;
        Double l1=latlng.latitude;
        Double l2=latlng.longitude;
        String coordl1 = l1.toString();
        String coordl2 = l2.toString();
        obj.execute(coordl1,coordl2);
        Toast.makeText(this,"City", Toast.LENGTH_SHORT).show();
        return false;
    }

    @Override
    public void processFinish(String output1, String output2, String output3, String output4, String output5)
    {
        marker.setTitle(output1);
        marker.setSnippet(output2+"\n"+output3+"\n"+output4+"\n");
    }
}